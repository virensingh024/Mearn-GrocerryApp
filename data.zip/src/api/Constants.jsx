export const Constants = { 
    BASE_URL: 'http://apolis-grocery.herokuapp.com/api/',
    IMAGE_URL: 'http://rjtmobile.com/grocery/images/',
}