import React, { useEffect, useState } from "react";
import axios from "axios";
import Product from "../Product";
import { Endpoints } from "../../../api/Endpoints";
import { useParams } from "react-router-dom";

const SubCategoryProduct = () => {
    const {subId} = useParams();
    const [products, setproducts] = useState([]);

    useEffect(() => {
        fetchData();
    }, [subId]);

    const fetchData = () => {
        axios.get(Endpoints.PRODUCT_BY_SUB_ID + subId)
        .then(response => setproducts(response.data.data ))
        .catch(error => console.log(error));
    }

    return(
        <div>
           <h1 className="text-center">All Products</h1>
            <div className="row">
                {
                    products.map(item => <Product data={item} />)
                }

            </div>
        </div>
    )
}
export default SubCategoryProduct;