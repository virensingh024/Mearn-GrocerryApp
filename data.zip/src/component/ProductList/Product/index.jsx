import { useState } from "react";
import { Constants } from "../../../api/Constants";
import "./product.css";
import { Link } from "react-router-dom";

const Product = (props) => {
  const { _id,productName, unit, price, mrp, image } = props.data;

  return (
    <div className="col-sm-4">
      <div className="card">
        <img src={Constants.IMAGE_URL + image} className="card-img-top" />
        <div className="card-body">
          <h5 className="card-title">{productName}</h5>
          <p className="card-text">{unit}</p>
          <h2>
            <span>&#8377;</span> {price}
            <span className="mrp">
              <del>
                <span>&#8377;</span> {mrp}
              </del>
            </span>
            <Link to={"/products/detail/"+_id} className="btn btn-primary btn-block">
              Go CART
            </Link>
            {/* <a href={"detail/"+_id} className="btn btn-primary btn-block">
              Go CART
            </a> */}
          </h2>
        </div>
      </div>
    </div>
  );
};

export default Product;