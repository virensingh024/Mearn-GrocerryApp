import axios from "axios";
import React, { useEffect, useState } from "react";
import { Endpoints } from "../../api/Endpoints";
import Product from "./Product";
import { useParams } from "react-router-dom";


const ProductList = () => {
  
    const {catId} = useParams();
    const [products, setproducts] = useState([]);

    useEffect(() => {
        fetchData();
    }, [catId]);

    const fetchData = () => {
        axios.get(Endpoints.PRODUCT_BY_CAT_ID + catId)
        .then(response => setproducts(response.data.data ))
        .catch(error => console.log(error));
    }


    return(
        <div>
           <h1 className="text-center">All Products</h1>
            <div className="row">
                {
                    products.map(item => <Product key={item.id} data={item} />)
                }

            </div>
        </div>
    )

}

export default ProductList;