import React,{component} from "react";

class UserRegistrationClass extends component{
    constructor(){
        super()
        this.state = {
            name: "mark"
        };
    }

    onChangeHandler = (event) => {
        this.setState({
            [event.target.name]:event.target.value
        })

    }

    render(){
        return(
            <div className="container">
                <form action="post">
                    <div className="form-group">
                        <label>Name</label>
                        <input type="text" name="first_name" value={this.state.name} onChange={this.onChangeHandler} className="form-control" />
                    </div>
                    <input type="submit" value="Submit" className="btn btn-primary" />
                </form>
            </div>
        )
    }
}

export default UserRegistrationClass;