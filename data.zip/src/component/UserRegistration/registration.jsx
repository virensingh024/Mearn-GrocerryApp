import axios from "axios";
import React, { useState } from "react";
import { Endpoints } from "../../api/Endpoints";
import "./Style.css";
import { Link } from "react-router-dom";
import { redirect } from "react-router-dom";
import NavBar from "../Navbar";

const UserRegistration = () => {
  const [state, setState] = React.useState({
    firstName: "",
    email: "",
    mobile: "",
    password: "",
    // status:1
  });
  const [responseText, setResponseText] = useState("");
  const [responseClass, setResponseClass] = useState("alert");

  const onChangeHandler = (evt) => {
    setState({
      ...state,
      [evt.target.name]: evt.target.value,
    });
    console.log(setState);
  };
  const onSubmitHandler = (evt) => {
    evt.preventDefault();
    axios
      .post(Endpoints.REGISTER_USER, state)
      .then(
        (response) => {
          setResponseText("Registration successfully");
          setResponseClass("alert alert-success");
          return <redirect to="/login" />;
        },
        (error) => {
          setResponseText(
            "Registration failed: " + error.response.data.message
          );
          setResponseClass("alert alert-danger");
          console.log(error.response.data);
        }
      )
      .catch((error) => console.log(error));
    //    console.log(state);
  };
  return (
    <>
      <NavBar />
      <div className="container">
        <br />
        {/* <h1>
          <Link to="/">GroceryApp</Link>
        </h1> */}
        <div className="row">
          <div className="col-lg-3"></div>
          <div className="col-lg-6">
            <div className="wrapper">
              <div class={responseClass} role="alert">
                {responseText}
              </div>
              <h2>Registration</h2>
              <hr />
              <form onSubmit={onSubmitHandler}>
                <div className="form-group">
                  <label for="exampleInputFirstName">First Name</label>
                  <input
                    type="text"
                    value={setState.first_name}
                    className="form-control"
                    name="firstName"
                    id="exampleInputFirstName"
                    aria-describedby="firstName"
                    onChange={onChangeHandler}
                  />
                </div>
                <div className="form-group">
                  <label for="exampleInputEmail1">Email address</label>
                  <input
                    type="email"
                    className="form-control"
                    id="exampleInputEmail1"
                    aria-describedby="emailHelp"
                    name="email"
                    onChange={onChangeHandler}
                  />
                  <small id="emailHelp" className="form-text text-muted">
                    We'll never share your email with anyone else.
                  </small>
                </div>
                <div className="form-group">
                  <label for="exampleInputMobile">Mobile</label>
                  <input
                    type="number"
                    className="form-control"
                    id="exampleInputMobile"
                    aria-describedby="mobileNumber"
                    name="mobile"
                    onChange={onChangeHandler}
                  />
                </div>
                <div className="form-group">
                  <label for="exampleInputPassword1">Password</label>
                  <input
                    type="password"
                    className="form-control"
                    id="exampleInputPassword1"
                    name="password"
                    onChange={onChangeHandler}
                  />
                </div>
                {/* <div className="form-group form-check">
                        <input type="checkbox" className="form-check-input" id="exampleCheck1" name="status" />
                        <label className="form-check-label" for="exampleCheck1">Check me out</label>
                    </div> */}
                <button type="submit" className="btn btn-primary">
                  Submit
                </button>
              </form>
              <br />
              <p className="text-center">
                <Link to="/login">Already Registered? Click Here</Link>
              </p>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};
export default UserRegistration;
