import React from "react";
import { Link } from "react-router-dom";
import { NavLink } from 'react-router-dom'


const NavBar = () => {
    return(
        <nav className="navbar navbar-expand-lg navbar-dark bg-dark">
            <NavLink className="navbar-brand" to="/">Grocerry</NavLink>
            <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            </button>

            <div className="collapse navbar-collapse" id="navbarSupportedContent">
                <ul className="navbar-nav mr-auto">
                    <li className="nav-item">
                        <NavLink className="nav-link" to="/" >
                        Home
                        </NavLink>
                    </li>
                    {/* <li className="nav-item">
                        <NavLink className="nav-link" to="/products/3" >
                        Products
                        </NavLink>
                    </li> */}
                    <li className="nav-item">
                        <NavLink className="nav-link" to="/about">
                        About
                        </NavLink>
                    </li>
                    <li className="nav-item">
                        <NavLink className="nav-link" to="/contact">
                        Contact
                        </NavLink>
                    </li>
                    
                </ul>
                <ul className="navbar-nav mr-auto1" styleName="float:right;">
                    <li className="nav-item">
                        <NavLink className="nav-link" to="/login">
                        Login
                        </NavLink>
                    </li>
                </ul>
            </div>
        </nav>
    );
}

export default NavBar;