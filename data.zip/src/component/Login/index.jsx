import React, { useState } from "react";
import { Endpoints } from "../../api/Endpoints";
import axios from "axios";
import "./Style.css";
import { Link } from "react-router-dom";
import NavBar from "../Navbar";

const Login = () => {
  const [state, setState] = useState({
    email: "",
    password: "",
  });
  const [responseText, setResponseText] = useState("");
  const [responseClass, setResponseClass] = useState("alert");

  const onChangeHandler = (evt) => {
    setState({
      ...state,
      [evt.target.name]: evt.target.value,
    });
    console.log(setState);
  };
  const onSubmitHandler = (evt) => {
    evt.preventDefault();
    axios
      .post(Endpoints.LOGIN_USER, state)
      .then(
        (response) => {
          setResponseText("login successfull");
          setResponseClass("alert alert-success");
          localStorage.setItem("token", response.data.token);
          localStorage.setItem(
            "user_details",
            JSON.stringify(response.data.user)
          );
          //   console.log(dataInput);
        },
        (error) => {
          setResponseText("login failed: " + error.response.data.message);
          setResponseClass("alert alert-danger");
          console.log(error.response.data);
        }
      )
      .catch((error) => console.log(error));
    //    console.log(state);
  };
  return (
    <>
     <NavBar />
      <div className="container">
        <br />
       
        {/* <h1>
          <Link to="/">GroceryApp</Link>
        </h1> */}
        <div className="row">
          <div className="col-lg-3"></div>
          <div className="col-lg-6">
            <div className="wrapper">
              <div class={responseClass} role="alert">
                {responseText}
              </div>
              <h2>Login</h2>
              <hr />
              <form onSubmit={onSubmitHandler}>
                <div className="form-group">
                  <label htmlFor="exampleInputEmail1">Email address</label>
                  <input
                    type="email"
                    className="form-control"
                    value={state.email}
                    id="exampleInputEmail1"
                    aria-describedby="emailHelp"
                    name="email"
                    onChange={onChangeHandler}
                  />
                </div>

                <div className="form-group">
                  <label htmlFor="exampleInputPassword1">Password</label>
                  <input
                    type="password"
                    className="form-control"
                    value={state.password}
                    id="exampleInputPassword1"
                    name="password"
                    onChange={onChangeHandler}
                  />
                </div>

                <button type="submit" className="btn btn-primary">
                  Login
                </button>
              </form>
              <br />
              <p className="text-center">
                <Link to="/registration">New User? Click Here</Link>
              </p>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Login;
