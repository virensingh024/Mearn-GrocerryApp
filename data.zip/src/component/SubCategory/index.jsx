import React, { useEffect, useState } from "react";
import axios from "axios";
import { Endpoints } from "../../api/Endpoints";
import { useParams } from "react-router-dom";
import { Link } from "react-router-dom";

const SubCategory = () => {
    const {catId} = useParams();
    const [subcategories, setSubCategories] = useState([]);

    useEffect(() => {
        fetchData()
    },[catId]);

    const fetchData = () => {
        axios
        .get(Endpoints.SUB_CATEGORY_URL + catId)
        .then(response => setSubCategories(response.data.data))
        .then(error => console.log(error))
    }

    return(
        <div>
        <h2 className="text-center">Sub Category</h2>
        <ul className="list-group">
            {
                subcategories.map(item => <li className="list-group-item"><Link to={"/products/subcategory/"+item.catId+"/"+ item.subId}>{ item.subName }</Link></li> )
            }
        </ul>
    </div>
    )
    
}

export default SubCategory;