import React, { useState, useEffect } from "react";
import axios from "axios";
import Category from "./Category";

const CategoryList = () => {
    const [Categories, setCategories] = useState([]);
    useEffect(() => {
        fetchData();
    }, [])

    const fetchData = () => {
        axios.get("http://apolis-grocery.herokuapp.com/api/category")
        .then((response) => {
            console.log(response.data.data);
            setCategories(response.data.data);
        } )
        .catch((error) => {
            console.log(error);
        } )
    }

    return(
        <div>
            <h1 className="text-center">All Categories</h1>
            <div className="row">
                {
                    Categories.map(item => <Category data={ item } />)
                }
               
            </div>
        </div>
    )
}

export default CategoryList;