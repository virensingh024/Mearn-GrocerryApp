import React from "react";
import NavBar from "../../component/Navbar";
import Header from "../../component/Header";
import CategoryList from "../../component/CategoryList";

const HomePage = () => {
    return(
        <>
            <NavBar />
            <Header />
            <div className="container">
                <CategoryList />
            </div>
        </>
    )
}
export default HomePage;