import React from "react";
import NavBar from "../../../component/Navbar";
import SubCategory from "../../../component/SubCategory";
import SubCategoryProduct from "../../../component/ProductList/SubCategoryProduct";

const SubCateogoryProductPage = () => {
  return (
    <>
      <NavBar />
      <div className="container">
        <div className="row">
          <div className="col-md-3">
            <SubCategory />
          </div>
          <div className="col-md-9">
            <SubCategoryProduct />
          </div>
        </div>
      </div>
    </>
  );
};

export default SubCateogoryProductPage;
