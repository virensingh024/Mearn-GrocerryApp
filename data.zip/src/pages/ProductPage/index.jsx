import React from "react";
import ProductList from "../../component/ProductList";
import NavBar from "../../component/Navbar";
import SubCategory from "../../component/SubCategory";

const ProductPage = () => {
  return (
    <>
      <NavBar />
      <div className="container">
        <div className="row">
          <div className="col-md-3">
            <SubCategory />
          </div>
          <div className="col-md-9">
            <ProductList />
          </div>
        </div>
      </div>
    </>
  );
};

export default ProductPage;
