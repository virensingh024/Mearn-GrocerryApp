import React, { useEffect, useState } from "react";
import axios from "axios";
import { Endpoints } from "../../api/Endpoints";
import NavBar from "../../component/Navbar";
import { Constants } from "../../api/Constants";
import './ProductDetailPage.module.css';
import { useParams } from "react-router-dom";

const ProductDetailsPage = () => {
  // const id = "5de4a2b6a32d0906687812ea";
  // console.log(useParams());
  const { id } = useParams();
  const [product, setProduct] = useState({});

  useEffect(() => {
    fetchData();
  }, [id]);

  const fetchData = () => {
    axios
      .get(Endpoints.PRODUCT_BY_ID + id)
      .then((response) => setProduct(response.data.data))
      .catch((error) => console.log(error));
  };

  return (
    <>
      <NavBar />
      <div className="container">
        <div className="wrapper">
            <div className="row">
                <div className="col-lg-6">
                    <img src={ Constants.IMAGE_URL + product.image } alt="" className="img-fluid" />
                </div>
                <div className="col-lg-6">
                    <h3>{ product.productName }</h3>
                    <p>{ product.unit }</p>
                    <p>{ product.description }</p>
                    <br/>
                    <h2>
                    <span>&#8377;</span>{ product.price }
                    <span className="mrp">
                        <span>&#8377;</span>{ product.mrp }
                    </span>
                    </h2>
                    <br/>
                    <button className="btn btn-primary">Add to cart</button>
                </div>
            </div>
        </div>
      </div>
    </>
  );
};
export default ProductDetailsPage;
