import React from "react";
import NavBar from "../../component/Navbar";

const ContactPage = () => {
  return (
    <>
      <NavBar />
      <div className="jumbotron text-center">
        <div className="display-4">Contact Us</div>
        <p className="lead">This is about page for contact app</p>
      </div>
      <div className="container">
        <section>
          <p>
            Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ipsa sit
            accusamus assumenda ad soluta minus quos odit necessitatibus dolor,
            laborum, numquam odio deserunt? Nam suscipit doloribus tempore
            laboriosam a est! Lorem ipsum, dolor sit amet consectetur
            adipisicing elit. Magni ratione amet autem aliquid. Optio, vitae
            necessitatibus doloribus quo fuga harum, eaque quidem quod provident
            totam rerum sed tenetur! Eos, aut?
          </p>
          <p>
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Repellat,
            impedit asperiores aperiam cum similique aspernatur repudiandae
            recusandae blanditiis repellendus sapiente nam, laborum eligendi
            quo. Molestiae in omnis maiores repudiandae suscipit.
          </p>
        </section>
      </div>
    </>
  );
};

export default ContactPage;
