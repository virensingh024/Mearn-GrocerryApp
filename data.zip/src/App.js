// import ReactDOM from "react-dom/client";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import HomePage from "./pages/HomePage";
import ProductPage from "./pages/ProductPage";
import ProductDetailsPage from "./pages/ProductDetailsPage";
import AboutUsPage from "./pages/AboutUsPage";
import ContactPage from "./pages/ContactUs";
import SubCateogoryProductPage from "./pages/ProductPage/SubCategoryProductPage";
import UserRegistration from "./component/UserRegistration/registration";
import Login from "./component/Login";
// import UserRegistrationClass from "./component/UserRegistration/UserRegistrationClass";

function App() {
  return (
    <Router>
      <Routes>
          <Route path="/" element={ <HomePage /> } />
          <Route path="/about" element={ <AboutUsPage /> } />
          <Route path="/contact" element={ <ContactPage /> } />
          <Route path="/products/:catId" element={ <ProductPage /> } />
          <Route path="/products/detail/:id" element={ <ProductDetailsPage /> } />
          <Route path="/products/subcategory/:catId/:subId" element={ <SubCateogoryProductPage /> } />
          <Route path="/registration" element={ <UserRegistration /> } />
          <Route path="/login" element={ <Login /> } />
          {/* <Route path="/registration/class" element={ <UserRegistrationClass /> } /> */}
          
      </Routes>
    </Router>
    // <>
    //   {/* <HomePage /> */}
    //   {/* <ProductPage /> */}
    //   {/* <ProductDetailsPage /> */}
    // </>
  );
}

export default App;
